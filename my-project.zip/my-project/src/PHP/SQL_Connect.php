<?php
    header("Content-Type: text/html;charset=utf-8");
    header("Access-Control-Allow-Origin: *");

    $SQL_host = 'localhost';
    $SQL_user = 'root';
    $SQL_password = 'daybreak1';


    $SQL_link = new mysqli($SQL_host, $SQL_user, $SQL_password);
    if($SQL_link->connect_errno) {
        die("连接失败：" . $SQL_link->connect_error);
    }
    $SQL_link->set_charset('utf8');
?>