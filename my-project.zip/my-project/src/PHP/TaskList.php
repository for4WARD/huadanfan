<?php
    header("Content-Type: text/html;charset=utf-8");
    header("Access-Control-Allow-Origin: *");

    //获取数据
    include 'SQL_Connect.php';
    $SQL_link->select_db("server");
    $operate = "SELECT * FROM tasklist";
    $response = $SQL_link->query($operate);
    $output = array();
    while($tmp = $response->fetch_assoc()) {
        array_push($output,$tmp);
    }
    //输出结果
    die(json_encode($output));
?>