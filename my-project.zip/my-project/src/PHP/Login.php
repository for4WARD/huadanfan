<?php
    header("Content-Type: text/html;charset=utf-8");
    header("Access-Control-Allow-Origin: *");

    $restJson = file_get_contents("php://input");
    $_POST = json_decode($restJson, true);

    $flag = 0;

    //从前端获取参数
    $UserUid = $_POST['uid'];
    $UserPassowrd = $_POST['password'];

    //连接数据库
    include 'SQL_Connect.php';

    //验证登录信息
    $SQL_link->select_db("server");
    $operate = "SELECT Password FROM userlist WHERE UID='$UserUid'";
    $response = $SQL_link->query($operate);
    $result = $response->fetch_assoc();
    if($UserPassowrd == $result["Password"])
        $flag = 1;

    //输出结果
    if($flag == 0) {
        $output = array(
            'data' => array(
                'uid' => 0,
                'name' => "",
                'result' => 0
            )
        );
    }
    else {
        $operate = "SELECT UserName FROM userlist WHERE UID='$UserUid'";
        $response = $SQL_link->query($operate);
        $result = $response->fetch_assoc();
        $UserName = $result["UserName"];

        $output = array(
            'data' => array(
                'uid' => $UserUid,
                'name' => $UserName,
                'result' => $flag
            )
        );
    }
    die(json_encode($output));
?>