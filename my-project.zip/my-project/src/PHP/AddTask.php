<?php
    header("Content-Type: text/html;charset=utf-8");
    header("Access-Control-Allow-Origin: *");

    //数据初始化
    $TaskID = 100001;
    $TaskName = $_POST['name'];
    $TaskSubject = $_POST['subject'];
    $TaskDescribe = $_POST['describe'];
    $TaskDDL = $_POST['ddl'];

    //连接数据库
    include 'SQL_Connect.php';
    $SQL_link->select_db("server");

    //分配ID
    $operate = "SELECT TaskNum FROM data";
    $response = $SQL_link->query($operate);
    $result = $response->fetch_assoc();
    $tmp = (int)$result['TaskNum'];
    $TaskID += $tmp;

    //更新数据库
    $operate = "UPDATE data SET TaskNum = $tmp + 1 WHERE TaskNum = $tmp";
    if(!($SQL_link->query($operate))) {
        die("更新失败:" . $SQL_link->error);
    }

    //生成URL
    $TaskURL = "";

    //信息打包
    $output = array(
        'data' => array(
            'uid' => $TaskID,
            'name' => $TaskName,
            'describe' => $TaskDescribe,
            'ddl' => $TaskDDL,
            'url' => $TaskURL
        )
    );

    //录入数据库
    $operate = "INSERT INTO
    tasklist (uid, name, TaskSubject, TaskDescribe, ddl)
    VALUES ($TaskID, '$TaskName', '$TaskSubject', '$TaskDescribe', $TaskDDL)";
    if(!($SQL_link->query($operate))) {
        die("添加失败:" . $SQL_link->error);
    }
    $SQL_link->close();

    //输出结果
    die(json_encode($output));
?>