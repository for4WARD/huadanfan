<?php
    header("Content-Type: text/html;charset=utf-8");
    header("Access-Control-Allow-Origin: *");

    //从前端获取参数
    $UserName = $_POST['username'];
    $UserPassowrd = $_POST['password'];
    $UserUid = 10001;

    //连接数据库
    include 'SQL_Connect.php';

    //分配ID
    $SQL_link->select_db("server");
    $operate = "SELECT UserNum FROM data";
    $response = $SQL_link->query($operate);
    $result = $response->fetch_assoc();
    $tmp = (int)$result["UserNum"];
    $UserUid += $tmp;

    //更新数据库
    $operate = "UPDATE data SET UserNum = $tmp + 1 WHERE TaskNum = $tmp";
    if(!($SQL_link->query($operate))) {
        die("更新失败:" . $SQL_link->error);
    }

    //信息打包
    $output = array(
        'data' => array(
            'uid' => $UserUid,
            'name' => $UserName
        )
    );

    //录入数据库
    $operate = "INSERT INTO
    userlist (UID, Password, UserName)
    VALUES ('$UserUid', '$UserPassowrd', '$UserName')";
    if(!($SQL_link->query($operate))) {
        die("添加失败:" . $SQL_link->error);
    }
    $SQL_link->close();

    //输出结果
    die(json_encode($output));
?>