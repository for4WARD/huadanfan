<?php
    header("Content-Type: text/html;charset=utf-8");
    header("Access-Control-Allow-Origin: *");

    //从前端获取参数
    $UserUid = $_POST['uid'];

    //获取数据
    include 'SQL_Connect.php';
    $SQL_link->select_db("server");
    $operate = "SELECT UserName FROM userlist WHERE UID='$UserUid'";
    $response = $SQL_link->query($operate);
    $result = $response->fetch_assoc();
    $UserName = $result["UserName"];

    //输出结果
    $output = array(
        'data' => array(
            'uid' => $UserUid,
            'name' => $UserName,
        )
    );
    die(json_encode($output));
?>