<?php
    header("Content-Type: text/html;charset=utf-8");
    header("Access-Control-Allow-Origin: *");

    //获取文件路径
    $fileInfo = $_FILES['file'];
    $filePath=$fileInfo['tmp_name'];

    //生成文件名
    $taskid = $_POST['TaskID'];
    $filename = $fileInfo['name'];

    //把临时目录下的文件移动到对应作业文件夹下，文件名为用户UID
    move_uploaded_file($filePath,"E:\project\my-project\homeworklib\\$taskid\\".$filename);

    // $UserRank = ((int)$_POST['UserID']) % 100;
    // $Status = rand(1,3);
    // //更新数据库
    // $operate = "UPDATE tasklist SET s$UserRank = $Status WHERE uid = $taskid";
    // if(!($SQL_link->query($operate))) {
    //     die("更新失败:" . $SQL_link->error);
    // }

    die("提交成功");
?>