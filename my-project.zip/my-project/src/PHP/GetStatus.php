<?php
    header("Content-Type: text/html;charset=utf-8");
    header("Access-Control-Allow-Origin: *");

    //从前端获取参数
    $UserUid = $_POST['uid'];
    $UserRank = ((int)$UserUid) % 100;
    $TaskID = $_POST['hid'];
    $Status = 0;

    //获取数据
    include 'SQL_Connect.php';
    $SQL_link->select_db("server");
    $operate = "SELECT s$UserRank FROM tasklist WHERE uid = $TaskID";
    $response = $SQL_link->query($operate);
    $result = $response->fetch_assoc();
    $Status = $result["s$UserRank"];

    //输出结果
    $output = array(
        'data' => array(
            'stat' => $Status,
        )
    );
    die(json_encode($output));
?>