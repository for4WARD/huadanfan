<?php
    $flag = 0;

    //从前端获取参数
    $UserUid = $_POST['uid'];
    $UserPassowrd = $_POST['password'];

    //连接数据库
    include 'SQL_Connect.php';

    //验证登录信息
    $SQL_link->select_db($db_server);
    $operate = "SELECT Password FROM table3 WHERE UID='$UserUid'";
    $response = $SQL_link->query($operate);
    $result = $response->fetch_assoc();
    if($UserPassowrd == $result["Password"])
        $flag = 1;
    
    //输出结果
    $output = array(
        'data' => array(
            'uid' => $UserUid,
            'password' => $UserPassowrd,
            'result' => $flag
        )
    );
    die(json_encode($output));
?>